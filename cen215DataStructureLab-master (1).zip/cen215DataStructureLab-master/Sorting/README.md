# Sorting

## Homework 1

Implement every sort we have covered on Lab sessions on a single C program and measure their performances. Use your "name" and "student number" for unsorted arrays. Print performance reports and sorted arrays. Put a screenshot of your output (terminal) to your homework folder.

1. Fork our *cen215DataStructureLab* repository.
2. Update it with your homework added.
3. Create pull request.

Due date and time:  **27.10.2020 @17:00**